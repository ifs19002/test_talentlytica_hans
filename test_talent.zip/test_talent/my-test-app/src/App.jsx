// import { useState } from 'react';
// import reactLogo from './assets/react.svg';
// import viteLogo from './vite.svg';
// import './App.css';

// // function App() {
  import React from 'react';

  class App extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        jsonData: null
      };
    }
  
    componentDidMount() {
      // Mengambil data dari API atau sumber daya lainnya
      // Di sini, kita hanya menggunakan data yang telah ditentukan
      const data = {
        aspek_penilaian_1: {},
        aspek_penilaian_2: {},
        aspek_penilaian_3: {},
        aspek_penilaian_4: {}
      };
  
      // Mengisi data dengan nilai 1 hingga 10
      for (let i = 1; i <= 10; i++) {
        data.aspek_penilaian_1[`mahasiswa_${i}`] = 1;
        data.aspek_penilaian_2[`mahasiswa_${i}`] = 1;
        data.aspek_penilaian_3[`mahasiswa_${i}`] = 1;
        data.aspek_penilaian_4[`mahasiswa_${i}`] = 10;
      }
  
      // Mengupdate state dengan data yang dihasilkan
      this.setState({ jsonData: data });
    }
  
    render() {
      const { jsonData } = this.state;
  
      return (
        <div>
          {jsonData ? (
            <pre>{JSON.stringify(jsonData, null, 2)}</pre>
          ) : (
            <p>Loading...</p>
          )}
        </div>
      );
    }
  }
  
  export default App;